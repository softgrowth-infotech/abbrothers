<style>
    .logo{
        width: 180px;
        height: 80px;
    }
 
</style>


<header class="top-navbar">
		<nav class="navbar navbar-expand-lg navbar-light " style="background-color: #fff;">
			<div class="container">
				<a class="navbar-brand" href="food">
				<img src="images/A.B..png" alt="A.B.BROTHER'S" class="logo">
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-rs-food" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
				  <span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbars-rs-food">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item active mr-1"><a class="nav-link" href="food">Home</a></li>
						<li class="nav-item mr-1"><a class="nav-link" href="about">About</a></li>
						<li class="nav-item mr-1"><a class="nav-link" href="franchise">Franchise</a></li>	
						<!-- <li class="nav-item"><a class="nav-link" href="about.php">Gallery</a></li>	 -->
						<li class="nav-item mr-1"><a class="nav-link" href="contact">Contact</a></li>
					</ul>
				</div>
			</div>
		</nav>
	</header>